 Webgl-boilerplate for Graphics Spring 2019
