var obs_two_vc;
function initObs2(gl) {
   positionBuffer = gl.createBuffer();

  gl.bindBuffer(gl.ARRAY_BUFFER, positionBuffer);
  positions = [
    
    // Front face
    0-0.3, 0, 0,
    0-0.3, 0.3, 0,
    0+0.3, 0.3, 0,
    0+0.3, 0, 0,

    0+0.3, 0, 0,
    0+0.3, 0, 0.01,
    0+0.3, 0.3, 0.01,
    0+0.3, 0.3, 0,

    0-0.3, 0, 0,
    0-0.3, 0, 0.01,
    0-0.3, 0.3, 0.01,
    0-0.3, 0.3, 0,

    
    0-0.3-0.02,0.3,0,
    0.3+0.02,0.3,0,
    0.3+0.02,0.4,0,
    0-0.3-0.02,0.4,0,

    0.3+0.02,0.3,0,
    0.3+0.02,0.4,0,
    0.3+0.02,0.4,0.01,
    0.3+0.02,0.3,0.01,

    0-0.3-0.02,0.3,0,
    0-0.3-0.02,0.4,0,
    0-0.3-0.02,0.4,0.01,
    0-0.3-0.02,0.3,0.01,

];
  var i=0;
  while(i<positions.length){
    if(i%3==(1))
      positions[i] = positions[i] + 0.5;
    i++;
  }
  positions.push(
    0-0.3,0.3,0,
    0-0.3,0,0,
    0-0.3-0.01,0,0,
    0-0.3-0.01,0.3,0,

    0.3,0.3,0,
    0.3,0,0,
    0.3-0.01,0,0,
    0.3-0.01,0.3,0
  );
  obs_two_vc = positions.length/3;

  gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(positions), gl.STATIC_DRAW);

  textureCoordBuffer = gl.createBuffer();
  gl.bindBuffer(gl.ARRAY_BUFFER, textureCoordBuffer);

    textureCoordinates = [

    0.0,  1.0,
    0.0,  0.0,
    1.0,  0.0,
    1.0,  1.0,

    0.0,  1.0,
    0.0,  0.0,
    1.0,  0.0,
    1.0,  1.0,

    0.0,  0.0,
    1.0,  0.0,
    1.0,  1.0,
    0.0,  1.0,

    0.0,  0.0,
    1.0,  0.0,
    1.0,  1.0,
    0.0,  1.0,

    0.0,  0.0,
    1.0,  0.0,
    1.0,  1.0,
    0.0,  1.0,

    0.0,  0.0,
    1.0,  0.0,
    1.0,  1.0,
    0.0,  1.0,

    0.0,  0.0,
    1.0,  0.0,
    1.0,  1.0,
    0.0,  1.0,

    0.0,  0.0,
    1.0,  0.0,
    1.0,  1.0,
    0.0,  1.0,
  ];

  gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(textureCoordinates),
                gl.STATIC_DRAW);

   indexBuffer = gl.createBuffer();
  gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, indexBuffer);

  var indices = [];
  for(i=0;i<8;i++){
    indices.push(4*i+0);
    indices.push(4*i+1);
    indices.push(4*i+2);

    indices.push(4*i+0);
    indices.push(4*i+2);
    indices.push(4*i+3);
  }

  gl.bufferData(gl.ELEMENT_ARRAY_BUFFER,
      new Uint16Array(indices), gl.STATIC_DRAW);
  return {
    position: positionBuffer,
    textureCoord: textureCoordBuffer,
    indices: indexBuffer,
  };
}


function drawObs2(gl, programInfo, obs2, texture, deltaTime){

    fieldOfView = Math.PI /4;   // in radians
    aspect = gl.canvas.clientWidth / gl.canvas.clientHeight;
    zNear = 0.1;
    zFar = 1000.0;
    projectionMatrix = mat4.create();

  mat4.perspective(projectionMatrix,
                   fieldOfView,
                   aspect,
                   zNear,
                   zFar);

   modelViewMatrix = mat4.create();

  mat4.translate(modelViewMatrix,     // destination matrix
                 modelViewMatrix,     // matrix to translate
                 obs2.position);  // amount to translate
  {
     numComponents = 3;
     type = gl.FLOAT;
     normalize = false;
     stride = 0;
     offset = 0;
    gl.bindBuffer(gl.ARRAY_BUFFER, obs2.buffer.position);
    gl.vertexAttribPointer(
        programInfo.attribLocations.vertexPosition,
        numComponents,
        type,
        normalize,
        stride,
        offset);
    gl.enableVertexAttribArray(
        programInfo.attribLocations.vertexPosition);
  }

  {
     num = 2;
     type = gl.FLOAT; 
     normalize = false; 
     stride = 0; 
     offset = 0; 
    gl.bindBuffer(gl.ARRAY_BUFFER, obs2.buffer.textureCoord);
    gl.vertexAttribPointer(programInfo.attribLocations.textureCoord, num, type, normalize, stride, offset);
    gl.enableVertexAttribArray(programInfo.attribLocations.textureCoord);
    }

  gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, obs2.buffer.indices);

  gl.useProgram(programInfo.program);

  gl.uniformMatrix4fv(
      programInfo.uniformLocations.projectionMatrix,
      false,
      projectionMatrix);
  gl.uniformMatrix4fv(
      programInfo.uniformLocations.modelViewMatrix,
      false,
      modelViewMatrix);

    gl.activeTexture(gl.TEXTURE0);

    gl.bindTexture(gl.TEXTURE_2D, texture);

    gl.uniform1i(programInfo.uniformLocations.uSampler, 0);  


    gl.drawElements(gl.TRIANGLES, (obs_two_vc*6)/4, gl.UNSIGNED_SHORT, 0);

  // cubeRotation+=deltaTime;
}
