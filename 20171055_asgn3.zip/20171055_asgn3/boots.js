var boots_vc;
function initBoots(gl) {
   positionBuffer = gl.createBuffer();

  gl.bindBuffer(gl.ARRAY_BUFFER, positionBuffer);
	var x = x
  // Now create an array of positions for the cube.
  positions = [
   x, x,  0.1,
   0.1, x,  0.1,
   0.1,  0.1,  0.1,
   x,  0.1,  0.1,
  
   x, x, x,
   x,  0.1, x,
   0.1,  0.1, x,
   0.1, x, x,
  
   x,  0.1, x,
   x,  0.1,  0.1,
   0.1,  0.1,  0.1,
   0.1,  0.1, x,
  
   x, x, x,
   0.1, x, x,
   0.1, x,  0.1,
   x, x,  0.1,
  
   0.1, x, x,
   0.1,  0.1, x,
   0.1,  0.1,  0.1,
   0.1, x,  0.1,
  
   x, x, x,
   x, x,  0.1,
   x,  0.1,  0.1,
   x,  0.1, x,

    ];
  
  var i;
  
  boots_vc = positions.length/3;


  gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(positions), gl.STATIC_DRAW);


  textureCoordBuffer = gl.createBuffer();
  gl.bindBuffer(gl.ARRAY_BUFFER, textureCoordBuffer);

  textureCoordinates = [
    // Front
    1.0,  1.0,
    0.0,  1.0,
    0.0,  0.0,
    1.0,  0.0,

    0.0,  1.0,
    0.0,  0.0,
    1.0,  0.0,
    1.0,  1.0,

    0.0,  1.0,
    0.0,  0.0,
    1.0,  0.0,
    1.0,  1.0,

    0.0,  0.0,
    1.0,  0.0,
    1.0,  1.0,
    0.0,  1.0,

    0.0,  0.0,
    1.0,  0.0,
    1.0,  1.0,
    0.0,  1.0,

    0.0,  0.0,
    1.0,  0.0,
    1.0,  1.0,
    0.0,  1.0,
  ];

  gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(textureCoordinates),
                gl.STATIC_DRAW);

   indexBuffer = gl.createBuffer();
  gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, indexBuffer);

  var indices = [];
  for(i=0;i<6;i++){
    indices.push(4*i+0);
    indices.push(4*i+1);
    indices.push(4*i+2);

    indices.push(4*i+0);
    indices.push(4*i+2);
    indices.push(4*i+3);
  }


  gl.bufferData(gl.ELEMENT_ARRAY_BUFFER,
      new Uint16Array(indices), gl.STATIC_DRAW);
  return {
    position: positionBuffer,
    textureCoord: textureCoordBuffer,
    indices: indexBuffer,
  };
}


function drawBoots(gl, programInfo, boot, texture, deltaTime){

    fieldOfView = Math.PI / 4;   // in radians
    aspect = gl.canvas.clientWidth / gl.canvas.clientHeight;
    zNear = 0.1;
    zFar = 1000.0;
    projectionMatrix = mat4.create();

  mat4.perspective(projectionMatrix,
                   fieldOfView,
                   aspect,
                   zNear,
                   zFar);

   modelViewMatrix = mat4.create();


  mat4.translate(modelViewMatrix,     // destination matrix
                 modelViewMatrix,     // matrix to translate
                 boot.position);  // amount to translate

  {
     numComponents = 3;
     type = gl.FLOAT;
     normalize = false;
     stride = 0;
     offset = 0;
    gl.bindBuffer(gl.ARRAY_BUFFER, boot.buffer.position);
    gl.vertexAttribPointer(
        programInfo.attribLocations.vertexPosition,
        numComponents,
        type,
        normalize,
        stride,
        offset);
    gl.enableVertexAttribArray(
        programInfo.attribLocations.vertexPosition);
  }

  {
     num = 2; // every coordinate composed of 2 values
     type = gl.FLOAT; // the data in the buffer is 32 bit float
     normalize = false; // don't normalize
     stride = 0; // how many bytes to get from one set to the next
     offset = 0; // how many bytes inside the buffer to start from
    gl.bindBuffer(gl.ARRAY_BUFFER, boot.buffer.textureCoord);
    gl.vertexAttribPointer(programInfo.attribLocations.textureCoord, num, type, normalize, stride, offset);
    gl.enableVertexAttribArray(programInfo.attribLocations.textureCoord);
    }

  gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, boot.buffer.indices);

  gl.useProgram(programInfo.program);

  gl.uniformMatrix4fv(
      programInfo.uniformLocations.projectionMatrix,
      false,
      projectionMatrix);
  gl.uniformMatrix4fv(
      programInfo.uniformLocations.modelViewMatrix,
      false,
      modelViewMatrix);

    gl.activeTexture(gl.TEXTURE0);

    gl.bindTexture(gl.TEXTURE_2D, texture);

    gl.uniform1i(programInfo.uniformLocations.uSampler, 0);  


    gl.drawElements(gl.TRIANGLES, 6, gl.UNSIGNED_SHORT, 0);

  // cubeRotation+=deltaTime;
}
