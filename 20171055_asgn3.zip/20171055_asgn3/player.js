var pvc;
function initPlayer(gl,flag) {
   positionBuffer = gl.createBuffer();
  gl.bindBuffer(gl.ARRAY_BUFFER, positionBuffer);
var x=0.05;
var y=0.08;
var z=0.3;
var w=0.15;
  positions = [
    
    0-x, 0.7, 0,
    0-x, 0.7, 0-0.1,
    x, 0.7, 0-0.1,
    x, 0.7, 0,

    x, 0.7, 0,
    x, 0.6, 0,
    0-x, 0.6, 0,
    0-x, 0.7, 0,

    x+0, 0.6, 0,
    x+0, 0.6, 0-0.1,
    x+0, 0.7, 0-0.1,
    x+0, 0.7, 0,

    0-x, 0.6, 0,
    0-x, 0.6, 0-0.1,
    0-x, 0.7+0, 0-0.1,
    0-x, 0.7+0, 0,

    0-x, 0.6, 0,
    0-x, 0.6, 0-0.1,
    x, 0.6, 0-0.1,
    x, 0.6, 0,


    0-0.1,0.5 ,0,
    0-w,0.5 ,0,
    0-w,z ,0,
    0-0.1,z ,0,

    0-w,z,0,
    0-w,z,-0.1,
    0-w,0.5,-0.1,
    0-w,0.5,0,


    0.1,0.5,0,
    w,0.5,0,
    w,z,0,
    0.1,z,0,

    w,z,0,
    w,z,-0.1,
    w,0.5,-0.1,
    w,0.5,0,


    0-0.1,0.6,0,
    -w,0.6,0,
    -w,0.5,0,
    -0.1,0.5,0,

    -w,0.5,0,
    -w,0.5,-0.1,
    -w,0.6,-0.1,
    -w,0.6,0,


    0.1,0.6 ,0,
    w,0.6 ,0,
    w,0.5 ,0,
    0.1,0.5 ,0,

    w,0.5 ,0,
    w,0.5 ,-0.1,
    w,0.6 ,-0.1,
    w,0.6 ,0,
    

    0-0.1, 0.6 , 0,
    0.1, 0.6 , 0,
    0.1, z , 0,
    0-0.1, z , 0,
    
    0-0.1, z, 0,
    0-0.1, z, -0.1,
    0-0.1, 0.6, -0.1,
    0-0.1, 0.6, 0,

    0.1, z , 0,
    0.1, z , -0.1,
    0.1, 0.6 , -0.1,
    0.1, 0.6 , 0,


    0-0.1,0.6 ,0,
    0.1,0.6 ,0,
    0.1,0.6 ,-0.1,
    0-0.1,0.6 ,-0.1,

    //Bagpack

    0-y, 0.6 , 0,
    y, 0.6 , 0,
    y, 0.2 , 0,
    0-y, 0.2 , 0,
    
    0-y, 0.2, 0,
    0-y, 0.2, -0.1,
    0-y, 0.4+0.2, -0.1,
    0-y, 0.4+0.2, 0,

    y, 0.0+0.2 , 0,
    y, 0.0+0.2 , -0.1,
    y, 0.4+0.2 , -0.1,
    y, 0.4+0.2 , 0,


    0-y,0.4+0.2 ,0,
    y,0.4+0.2 ,0,
    y,0.4+0.2 ,-0.1,
    0-y,0.4+0.2 ,-0.1,

    ];

     positions.push(
      0.1,z,0,
      0.01,z,0,
      0.01,0,0.1,
      0.1,0,0.1
    );

      //right leg
    positions.push(
      -0.1,z,0,
      -0.01,z,0,
      -0.01,0,-0.1,
      -0.1,0,-0.1
    );


  
  var i;
  pvc = positions.length/3;
  gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(positions), gl.STATIC_DRAW);

  textureCoordBuffer = gl.createBuffer();
  gl.bindBuffer(gl.ARRAY_BUFFER, textureCoordBuffer);

  textureCoordinates = [
  ];
  for(i=0;i<pvc/4;i++)
  {
        textureCoordinates.push(0.0,  0.0);
        textureCoordinates.push(1.0,  0.0);
        textureCoordinates.push(1.0,  1.0);
        textureCoordinates.push(0.0,  1.0);
  }

  gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(textureCoordinates),
                gl.STATIC_DRAW);

   indexBuffer = gl.createBuffer();
  gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, indexBuffer);

  var indices = [];
  for(i=0;i<pvc/4;i++){
    indices.push(4*i+0);
    indices.push(4*i+1);
    indices.push(4*i+2);

    indices.push(4*i+0);
    indices.push(4*i+2);
    indices.push(4*i+3);
  }


  gl.bufferData(gl.ELEMENT_ARRAY_BUFFER,
      new Uint16Array(indices), gl.STATIC_DRAW);
  return {
    position: positionBuffer,
    textureCoord: textureCoordBuffer,
    indices: indexBuffer,
  };
}


function drawPlayer(gl, programInfo, player, textureskin,texturecloth,texturejeans, texturebag, deltaTime){

    fieldOfView = Math.PI /4;   // in radians
    aspect = gl.canvas.clientWidth / gl.canvas.clientHeight;
    zNear = 0.1;
    zFar = 1000.0;
    projectionMatrix = mat4.create();

  mat4.perspective(projectionMatrix,
                   fieldOfView,
                   aspect,
                   zNear,
                   zFar);

   modelViewMatrix = mat4.create();

  mat4.translate(modelViewMatrix,     // destination matrix
                 modelViewMatrix,     // matrix to translate
                 player.position);  // amount to translate

    if(player.crouch==true)
    mat4.rotate(modelViewMatrix, modelViewMatrix, -Math.PI/10, [1,0,0]);

  {
     numComponents = 3;
     type = gl.FLOAT;
     normalize = false;
     stride = 0;
     offset = 0;
    gl.bindBuffer(gl.ARRAY_BUFFER, player.buffer.position);
    gl.vertexAttribPointer(
        programInfo.attribLocations.vertexPosition,
        numComponents,
        type,
        normalize,
        stride,
        offset);
    gl.enableVertexAttribArray(
        programInfo.attribLocations.vertexPosition);
  }

  {
     num = 2; 
     type = gl.FLOAT; 
     normalize = false; 
     stride = 0; 
     offset = 0; 
    gl.bindBuffer(gl.ARRAY_BUFFER, player.buffer.textureCoord);
    gl.vertexAttribPointer(programInfo.attribLocations.textureCoord, num, type, normalize, stride, offset);
    gl.enableVertexAttribArray(programInfo.attribLocations.textureCoord);
    }

  gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, player.buffer.indices);

  gl.useProgram(programInfo.program);

  gl.uniformMatrix4fv(
      programInfo.uniformLocations.projectionMatrix,
      false,
      projectionMatrix);
  gl.uniformMatrix4fv(
      programInfo.uniformLocations.modelViewMatrix,
      false,
      modelViewMatrix);

    gl.activeTexture(gl.TEXTURE0);

    gl.bindTexture(gl.TEXTURE_2D, textureskin);

    gl.uniform1i(programInfo.uniformLocations.uSampler, 0);  

    gl.bindTexture(gl.TEXTURE_2D, textureskin);
    gl.drawElements(gl.TRIANGLES, 9*6, gl.UNSIGNED_SHORT, 0);

    gl.bindTexture(gl.TEXTURE_2D, texturecloth);
    gl.drawElements(gl.TRIANGLES, 8*6, gl.UNSIGNED_SHORT, 9*12);

    gl.bindTexture(gl.TEXTURE_2D, texturejeans);
    gl.drawElements(gl.TRIANGLES, 2*6, gl.UNSIGNED_SHORT, 9*12+8*12);

    gl.bindTexture(gl.TEXTURE_2D, texturebag);
    gl.drawElements(gl.TRIANGLES, 2*6, gl.UNSIGNED_SHORT, 9*12+8*12+2*12);
}
