

var cubeRotation = 0.0;
var zero= 0
var buildings;
buildings = [];
var tracks;
tracks = [];
var trains;
trains = [];
var obstacles1;
obstacles1 = [];
var obstacles2;
obstacles2 = [];
var boots;
boots = [];
var coins;
coins = [];
var jets;
jets = [];
score = zero;
flag=zero;
flash = zero;
var gray;
gray = zero;
canvas = document.querySelector('#glcanvas');
gl = canvas.getContext('webgl') || canvas.getContext('experimental-webgl');


train_toptexture = loadTexture(gl,'train_top.png');
train_stexture = loadTexture(gl,'train_side.png');
bricktexture = loadTexture(gl, 'brick.jpg');
trackstexture = loadTexture(gl,'tracks.png');
skintexture = loadTexture(gl,'skin.png');
clothtexture = loadTexture(gl,'cloth.png');
cointexture = loadTexture(gl,'coin.jpg');
obstexture = loadTexture(gl,'obs.png');
jeanstexture = loadTexture(gl,'jean.jpg');
bootstexture = loadTexture(gl,'./boot.jpg');
bagtexture = loadTexture(gl,'./bagpack.jpg');
policetexture = loadTexture(gl,'./police.png');
jettexture = loadTexture(gl,'./jet.png');
train1texture = loadTexture(gl,'./1train.jpg');
train2texture = loadTexture(gl,'./2train.jpg');
grasstexture = loadTexture(gl,'./grass.jpg');
train_fronttexture = loadTexture(gl,'train_front.png');
player = {
  buffer: initPlayer(gl,flag),
  position: [0,-1,-5],
  jump: false,
  crouch: false,
  crouch_time: -1,
  superjump: false,
  superjump_time: -1,
  dead: false,
  slow: true,
  slow_time: 0,
  jet: false,
  jet_time: -1,
};
police = {
  buffer: initPlayer(gl,flag),
  position: [0,-1,-3],
}

main();
function main() {

  if (!gl) {
    alert('Unable to initialize WebGL. Your browser or machine may not support it.');
    return;
  }

  const vsSource = `
  attribute vec4 aVertexPosition;
  attribute vec3 aVertexNormal;
  attribute vec2 aTextureCoord;
  
  uniform mat4 uNormalMatrix;
  uniform mat4 uModelViewMatrix;
  uniform mat4 uProjectionMatrix;
  uniform highp float uFlash;
  uniform int uLevel;

  varying highp vec2 vTextureCoord;
  varying highp vec3 vLighting;

  void main(void) {
    gl_Position = uProjectionMatrix * uModelViewMatrix * aVertexPosition;
    vTextureCoord = aTextureCoord;

    highp vec3 ambientLight = vec3(0.2 + 0.1 + uFlash, 0.2 + 0.1 + uFlash, 0.3 + uFlash);
    highp vec3 directionalLightColor = vec3(1, 1, 1);
    highp vec3 directionalVector = normalize(vec3(0, -1, 1));

    highp vec4 transformedNormal = uNormalMatrix * vec4(aVertexNormal, 1.0);

    highp float directional = max(dot(transformedNormal.xyz, directionalVector), 0.0);
    if(uLevel==1 || uLevel==3)
      vLighting = ambientLight + (directionalLightColor * directional);
    else
      vLighting = vec3(1.0 + uFlash, 1.0 + uFlash, 1.0 + uFlash);
  }
  `;
  const fsSource = `
  varying highp vec2 vTextureCoord;
  varying highp vec3 vLighting;

  uniform sampler2D uSampler;
  uniform bool uGray;
  uniform highp float uFlash;

  void main(void) {
    if(uGray)
    {
      highp vec4 texelColor = texture2D(uSampler, vTextureCoord).rgba;
      highp float grayScale = dot(texelColor.rgb, vec3(0.199, 0.587, 0.114));
      highp vec3 grayImage = vec3(grayScale+uFlash, grayScale+uFlash, grayScale+uFlash);
      gl_FragColor = vec4(grayImage * vLighting, texelColor.a);
    }
    else
    {
      highp vec4 texelColor = texture2D(uSampler, vTextureCoord).rgba;
      highp vec3 Image = vec3(texelColor.r + uFlash, texelColor.g + uFlash, texelColor.b + uFlash);
      gl_FragColor = vec4(Image * vLighting, texelColor.a);
    }

  }
  `;

  const shaderProgram = initShaderProgram(gl, vsSource, fsSource);
  const shaderProgramtxt = initShaderProgram(gl, vsSource, fsSource);

  const programInfo = {
    program: shaderProgram,
    attribLocations: {
      vertexPosition: gl.getAttribLocation(shaderProgram, 'aVertexPosition'),
      vertexColor: gl.getAttribLocation(shaderProgram, 'aVertexColor'),
    },
    uniformLocations: {
      projectionMatrix: gl.getUniformLocation(shaderProgram, 'uProjectionMatrix'),
      modelViewMatrix: gl.getUniformLocation(shaderProgram, 'uModelViewMatrix'),
    },
  };
  
  const programInfotxt = {
    program: shaderProgramtxt,
    attribLocations: {
      vertexPosition: gl.getAttribLocation(shaderProgramtxt, 'aVertexPosition'),
      textureCoord: gl.getAttribLocation(shaderProgramtxt, 'aTextureCoord'),
    },
    uniformLocations: {
      projectionMatrix: gl.getUniformLocation(shaderProgramtxt, 'uProjectionMatrix'),
      modelViewMatrix: gl.getUniformLocation(shaderProgramtxt, 'uModelViewMatrix'),
      uSampler: gl.getUniformLocation(shaderProgramtxt, 'uSampler'),
    },
  };

  
  var i=0;
  while(i<20){
    buildings.push({buffer: initBuildings(gl),draw: drawBuildings,position: [3,0-1,-11*i],});
    buildings.push({buffer: initBuildings(gl),draw: drawBuildings,position: [0-3,0-1,-11*i],});
    i++;
  }

  var i=0;
  while(i<50){
    tracks.push({buffer: initTracks(gl),draw: drawTracks,position: [0,0-1,-5*i],});
    tracks.push({buffer: initTracks(gl),draw: drawTracks,position: [-4,0-1,-5*i],});
    tracks.push({buffer: initTracks(gl),draw: drawTracks,position: [4,0-1,-5*i],});
    i++;
  }

  var i=0;
  while(i<20){
    coins.push({buffer: initCoin(gl),position: [-1,-0.6,-i-10],rotation: 0,});
    i++;
  }

  var i=0;
  while(i<20){
    coins.push({buffer: initCoin(gl),position: [0,-0.6,-i-30],rotation: 0,});
    i++;
  }

  var i=0;
  while(i<20){
    coins.push({buffer: initCoin(gl),position: [0,-0.6,-i-50],rotation: 0,});
    coins.push({buffer: initCoin(gl),position: [1,-0.6,-i-50],rotation: 0, });
    coins.push({buffer: initCoin(gl),position: [-1,-0.6,-i-50],rotation: 0,});
    i++;
  }

  var i=0;
  while(i<50){
    coins.push({buffer: initCoin(gl),position: [0,1.2,-i-75],rotation: 0,});
    coins.push({buffer: initCoin(gl),position: [1,1.2,-i-75],rotation: 0,});
    coins.push({buffer: initCoin(gl),position: [-1,1.2,-i-75],rotation: 0,});
    i++;
  }

  var i=0;
  while(i<20){
    coins.push({buffer: initCoin(gl),position: [0,-0.8,-i-135],rotation: 0,});
    i++;
  }

  var k = -1.1;
  var t = './train_top.png';
  var s = './train_side.png';
  var f = './train_front.png';

  trains.push({
    buffer: initTrains(gl),
    position: [k, -0.8,-30],
    top: loadTexture(gl,t),
    side: loadTexture(gl,s),
    front: loadTexture(gl,f),
  });

  trains.push({
    buffer: initTrains(gl),
    position: [0, -0.8,-95],
    top: loadTexture(gl,t),
    side: loadTexture(gl,s),
    front: loadTexture(gl,f),
  });

  trains.push({
    buffer: initTrains(gl),
    position: [-k, -0.8,-155],
    top: loadTexture(gl,t),
    side: loadTexture(gl,s),
    front: loadTexture(gl,f),
  });

  trains.push({
    buffer: initTrains(gl),
    position: [k, -0.8,-160],
    top: loadTexture(gl,t),
    side: loadTexture(gl,s),
    front: loadTexture(gl,f),
  });

  trains.push({
    buffer: initTrains(gl),
    position: [-k, -0.8,-200],
    top: loadTexture(gl,t),
    side: loadTexture(gl,s),
    front: loadTexture(gl,f),
  });

  trains.push({
    buffer: initTrains(gl),
    position: [k, -0.8,-1800],
    top: loadTexture(gl,t),
    side: loadTexture(gl,s),
    front: loadTexture(gl,f),
  });

  trains.push({
    buffer: initTrains(gl),
    position: [k, -0.8,-300],
    top: loadTexture(gl,t),
    side: loadTexture(gl,s),
    front: loadTexture(gl,f),
  });

  trains.push({
    buffer: initTrains(gl),
    position: [0, -0.8,-240],
    top: loadTexture(gl,t),
    side: loadTexture(gl,s),
    front: loadTexture(gl,f),
  });

  obstacles1.push({
    buffer: initObs1(gl),
    position: [0,-1,-20],
    col: false,
  });

  obstacles1.push({
    buffer: initObs1(gl),
    position: [1.3,-1,-41],
    col: false,
  });

  
  obstacles2.push({
    buffer: initObs2(gl),
    position: [-1.3,-1,-30],
    col: false,
    bush: false,
  });

  obstacles2.push({
    buffer: initObs1(gl),
    position: [-1.3,-1,-60],
    col: false,
    bush: true,
  });

  obstacles1.push({
    buffer: initObs1(gl),
    position: [0,-1,-60],
    col: false,
  });

  obstacles2.push({
    buffer: initObs1(gl),
    position: [1.3,-1,-60],
    col: false,
    bush: true,
  });

  obstacles2.push({
    buffer: initObs1(gl),
    position: [-1.3,-1,-130],
    col: false,
    bush: true,
  });

  obstacles2.push({
    buffer: initObs2(gl),
    position: [-1.3,-1,-135],
    col: false,
    bush: false,
  });

  boots.push({
    buffer: initBoots(gl),
    position: [1.3,-0.9,-40],
  });

  jets.push({
    buffer: initBoots(gl),
    position: [0-1.3,0-0.9,-72] 
  });

  var then = 0;
  
  document.getElementById('intro').play();  
  function render(now) {
    now *= 0.001;  
    const deltaTime = now - then;
    then = now;
    if(player.dead==true){
      alert('You died'+'\nFinal Score: '+score);
      return;
    }
    if(gray==0)
      gl.clearColor(135/256, 206/256, 235/256, 1.0);
    else
      gl.clearColor(220/256, 220/256, 220/256, 1.0);

    gl.clearDepth(1.0);                 
    gl.enable(gl.DEPTH_TEST);           
    gl.enable(gl.BLEND)
    gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA);
    gl.depthFunc(gl.LEQUAL);            

    gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
    drawScene(gl, programInfo, programInfotxt, deltaTime);
    
    var GrayBuffer = gl.getUniformLocation(programInfotxt.program, "uGray");
    gl.uniform1i(GrayBuffer, gray);

    var FlashBuffer = gl.getUniformLocation(programInfotxt.program, "uFlash");
    gl.uniform1f(FlashBuffer,flash);

    if(flash>0)
      flash-=0.01;
    else if(flash<=0)
      flash=0;
    
    
    tick_elements(now);
    tick_input();

    requestAnimationFrame(render);
  }
  requestAnimationFrame(render);
}

function drawScene(gl, programInfoflash, programInfotxt,texture, deltaTime) {

  var i=0;
  while(i<tracks.length){
    drawTracks(gl, programInfotxt, tracks[i],trackstexture, deltaTime);
    i++;
  }

  drawPlayer(gl, programInfotxt, player, skintexture,clothtexture,jeanstexture, bagtexture, deltaTime);
  drawPlayer(gl,programInfotxt,police,skintexture,policetexture,jeanstexture,policetexture,deltaTime);
  
  var i=0;
  while(i<buildings.length){  
    drawBuildings(gl, programInfotxt, buildings[i], bricktexture, deltaTime);
    i++;
  }

  var i=0;
  while(i<coins.length){
    drawCoin(gl,programInfotxt,coins[i],cointexture,deltaTime);    
    i++;
  }

  var i=0;
  while(i<trains.length){
    drawTrains(gl,programInfotxt,trains[i],trains[i].front,trains[i].side, trains[i].top ,deltaTime);
    i++;
  }
  
  var i=0;
  while(i<obstacles1.length){
    drawObs1(gl,programInfotxt,obstacles1[i],obstexture,deltaTime);
    i++;
  }

  var i=0;
  while(i<obstacles2.length){
    if(obstacles2[i].bush==false)
      drawObs2(gl,programInfotxt,obstacles2[i],obstexture,deltaTime);
    else
      drawObs1(gl,programInfotxt,obstacles2[i],grasstexture,deltaTime);

    i++;
  }
  
  var i=0;
  while(i<boots.length){
    drawBoots(gl,programInfotxt,boots[i],bootstexture,deltaTime);
    i++;
  }

  var i=0;
  while(i<jets.length){
    drawBoots(gl,programInfotxt,jets[i],jettexture,deltaTime);
    i++;
  }
}

function initShaderProgram(gl, vsSource, fsSource) {
  const vertexShader = loadShader(gl, gl.VERTEX_SHADER, vsSource);
  const fragmentShader = loadShader(gl, gl.FRAGMENT_SHADER, fsSource);

  const shaderProgram = gl.createProgram();
  gl.attachShader(shaderProgram, vertexShader);
  gl.attachShader(shaderProgram, fragmentShader);
  gl.linkProgram(shaderProgram);

  //if (!gl.getProgramParameter(shaderProgram, gl.LINK_STATUS)) {
   // alert('Unable to initialize the shader program: ' + gl.getProgramInfoLog(shaderProgram));
  //  return null;
//}

  return shaderProgram;
}

function loadShader(gl, type, source) {
  const shader = gl.createShader(type);

  gl.shaderSource(shader, source);

  gl.compileShader(shader);

  //if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) {
   // alert('An error occurred compiling the shaders: ' + gl.getShaderInfoLog(shader));
  //  gl.deleteShader(shader);
  //  return null;
 // }

  return shader;
}

function tick_elements(now){
  police.position[0] = player.position[0];
  playerbb = {
    y: player.position[1]+0.35,
    height: 0.7 + 0.01,
    z: player.position[2],
    width: 0.1 + 0.01,
  };

  if(player.slow!=true && police.position[2]<=1){
    police.position[2]+=0.05;
  }

    var i=0;
    while(i<coins.length){
      if( same_x(coins[i],player) ){
        coinbb = {
          y:coins[i].position[1],
          height: 0+0.1,
          z:coins[i].position[2],
          width: 0+0.01,
        };


        if( !(!detect_collision(playerbb,coinbb))  ){
          document.getElementById('coins').play();  
          flash = 0.2;
          coins.splice(i,1);
          score+=1;
          i--;
        }
      }
      i++;
    }

    var i=0;
    while(i<obstacles1.length){
      if(same_x(obstacles1[i],player)){
        obstacles1_bb = {
          y: -1+0.2,
          height : 0.4,
          z: obstacles1[i].position[2],
          width : 0.01,
        };

        if( detect_collision(playerbb,obstacles1_bb) && obstacles1[i].col!=true ){
          player.dead=true;
          obstacles1[i].col=true;
        }
      }
      i++;
    }

    var i=0;
    while(i<obstacles2.length){
      if(same_x(obstacles2[i],player)){
        if(obstacles2[i].bush==false)
          obstacles2_bb = {
            y: -1+0.2+0.5,
            height : 0.4,
            z: obstacles2[i].position[2],
            width : 0.01,
          };
        else{
          obstacles2_bb = {
            y: -1+0.2,
          height : 0.4,
          z: obstacles2[i].position[2],
          width : 0.01,
          };
        }

        if( detect_collision(playerbb,obstacles2_bb) && obstacles2[i].col==false  ){
          obstacles2[i].col=true;

          if(player.slow==true)
            player.dead=true;

          player.slow=true;
          police.position[2]=-3;
        }
      }
      i++;
    }

    var i=0;
    while(i<boots.length){
      if( same_x(boots[i],player) ){
        boot_bb = {
          y: boots[i].position[1],
          height: 0+0.2,
          z: boots[i].position[2],
          width: 0+0.2,
        };
          if(detect_collision(playerbb,boot_bb)){
            boots.splice(i,1);
            i--;
            player.superjump=true;
            player.superjump_time = now;
          }
      }
      i++;
    }

    //jets
    var i=0;
    while(i<jets.length){
      if( same_x(jets[i],player) ){
        jet_bb = {
          y: jets[i].position[1],
          height: 0+0.2,
          z: jets[i].position[2],
          width: 0+0.2,
        };
          if(detect_collision(playerbb,jet_bb)){
            jets.splice(i,1);
            i--;
            player.jet=true;
          }
      }
      i++;
    }

    train_flag=false;

    //trains
    var i=0;
    while(i<trains.length){
      if(same_x(trains[i],player)){
        train_bb={
          y: -0.45,
          height: 0.7,
          z: trains[i].position[2]-5,
          width: 10,
        };
        if( detect_collision(playerbb,train_bb) )
          if(player.position[1] >= -0.19)
            train_flag=true;
          else{
            player.dead=true;
          }
      }
      i++;
    }

  var i=0;
  while(i<buildings.length){
    buildings[i].position[2] = buildings[i].position[2] + 0.05;
    i++;
  }

  var i=0;
  while(i<tracks.length){
    tracks[i].position[2] = tracks[i].position[2] + 0.05;
    i++;
  }

  var i=0;
  while(i<obstacles1.length){
    obstacles1[i].position[2] = obstacles1[i].position[2] + 0.05;
    i++;
  }

  var i=0;
  while(i<obstacles2.length){
    obstacles2[i].position[2] = obstacles2[i].position[2] + 0.05;
    i++;
  }

  if(boots.length!=0)
    boots[0].position[2] = boots[0].position[2] + 0.05;

  var i=0;
  while(i<jets.length){
    jets[i].position[2] = jets[i].position[2] + 0.05;
    i++;
  }

  var i=0;
  while(i<coins.length){
    coins[i].position[2] = coins[i].position[2] + 0.05;
    coins[i].rotation = coins[i].rotation + 0.1;
    i++;
  }

  var i=0;
  while(i<trains.length){
    trains[i].position[2] = trains[i].position[2] + 0.1;
    i++;
  }
  
  if(Math.round(now*3)%2==0)
    flag=0;
  else 
      flag=1;
  player.buffer = initPlayer(gl,flag);
  police.buffer = initPlayer(gl,flag);

  if(player.superjump==true)
    maxh = 1;
  else
    maxh = 0;
  
  if(now - player.superjump_time > 5){
    player.superjump=false;
    player.superjump_time=0-1;
  }
  
  if(player.jump!=false && player.crouch!=true &&player.jet==false){
    if(player.position[1]<=maxh)
      player.position[1] = player.position[1] + 0.05;
    else
      player.jump=false;
  }
  else {
    if(player.position[1]>-1 &&train_flag!=true && player.jet!=true)
      player.position[1] = player.position[1] - 0.05;
  }

  if(player.jet!=false){
    if(player.jet_time==-1){
      player.position[1]=1;
      player.jet_time=now;
    }
    if(now-player.jet_time>15 && now-player.jet_time < 20){
      player.jet=false;
      player.jet_time = 0-1;
    }
  }


  if(player.slow!=false){
    if(player.slow_time==(0-1)){
      player.slow_time=now;
    }
    if(now-player.slow_time>3){
      player.slow=false;
      player.slow_time = 0-1;
    }

  }

  if(player.crouch!=false &&player.jet!=true){
    player.jump=false;
    if(player.crouch_time==0-1){
      player.crouch_time=now;
    }
    player.position[1]=0-1.25;

    if(now-player.crouch_time>=1){
      player.crouch_time = 0-1;
      player.crouch=false;
      player.position[1] = 0-1;
    }
  }

}

function tick_input(){
  Mousetrap.bind('right',function(){
    if(player.position[0]!=(1+0.3))
      player.position[0] = player.position[0] + (1+0.3);
  });

  Mousetrap.bind('left',function(){
    if(player.position[0]!=-1.3)
      player.position[0] = player.position[0] - 1.3;
  });
  Mousetrap.bind('up',function(){
    if(player.position[1]<=0-1 && player.crouch!=true)
      player.jump=true;
  });
  Mousetrap.bind('down',function(){
    if(player.crouch!=true&&player.jet!=true)
      player.crouch=true;
  });

  Mousetrap.bind('g',function(){gray=(gray+1)%2;});

}

function detect_collision(a, b) {
  return ((Math.abs(a.z - b.z) + Math.abs(a.z - b.z)) < (a.width + b.width)) &&
         ((Math.abs(a.y - b.y) + Math.abs(a.y - b.y)) < (a.height + b.height));
}

function same_x(a,b){
  return ( a.position[0]*b.position[0]>0 || (a.position[0]==0 && b.position[0]==0));
}

function loadTexture(gl, url) {
  const texture = gl.createTexture();
  gl.bindTexture(gl.TEXTURE_2D, texture);

  const level = 0;
  const internalFormat = gl.RGBA;
  const width = 2-1;
  const height = 2-1;
  const border = 1-1;
  const srcFormat = gl.RGBA;
  const srcType = gl.UNSIGNED_BYTE;
  const pixel = new Uint8Array([0, 0, 255, 255]);  // opaque blue
  gl.texImage2D(gl.TEXTURE_2D, level, internalFormat,
                width, height, border, srcFormat, srcType,
                pixel);

  const image = new Image();
  image.onload = function() {
    gl.bindTexture(gl.TEXTURE_2D, texture);
    gl.texImage2D(gl.TEXTURE_2D, level, internalFormat,
                  srcFormat, srcType, image);

    if (isPowerOf2(image.width) && isPowerOf2(image.height)) {
      
       gl.generateMipmap(gl.TEXTURE_2D);
    } else {
       
       gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
       gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
       gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
    }
  };
  image.src = url;

  return texture;
}

  
function isPowerOf2(value) {
  return (value & (value - 1)) == 0;
}
